from LinkedList.linkedList import *

link1 = LinkedList()
link1.insertAtBegin(10)